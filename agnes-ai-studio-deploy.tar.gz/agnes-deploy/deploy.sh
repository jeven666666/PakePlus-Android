#!/bin/bash
set -e
echo "========================================="
echo "  Agnes AI Studio 部署脚本"
echo "========================================="

if ! command -v node &> /dev/null; then
  echo "错误: 未安装 Node.js，请先安装 Node.js 18+"
  exit 1
fi

echo "1. 安装后端依赖..."
cd server && npm install

echo "2. 编译后端..."
npx tsc

echo "3. 创建目录..."
mkdir -p data uploads

echo "4. 配置环境变量..."
if [ ! -f .env ]; then
  cp .env.example .env
  JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  sed -i "s|在此替换为你的安全密钥-使用openssl-rand-hex-32生成|$JWT_SECRET|" .env
  echo "   已生成随机 JWT_SECRET"
  echo "   请编辑 .env 修改 CORS_ORIGINS 为你的域名"
fi

echo ""
echo "========================================="
echo "  部署完成！启动方式："
echo ""
echo "  开发: cd server && npx ts-node-dev --respawn src/index.ts"
echo "  生产: cd server && NODE_ENV=production node dist/src/index.js"
echo "  PM2:  pm2 start server/dist/src/index.js --name agnes-api"
echo ""
echo "  访问: http://localhost:3001"
echo "  测试: test@agnes.ai / 123456"
echo "========================================="
